# Ping Network 

An automated bot for the Ping Network VPN service to earn points and potentially qualify for airdrops.

## Prerequisites 📋

- Node.js v16+
- npm/yarn
- Git

## Installation 🛠️


1.git clone https://github.com/airdropinsiders/PingNetwork-Auto-Bot.git
cd PingNetwork-Auto-Bot

2.npm install


3.nano.env
masukan user.id & device id dengan format dibawah ini:
USER_ID=
DEVICE_ID= 
## Usage 🚀

4.jalankan :
node index.js

